<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" type="text/css" href="style.css" />
        <title>franceinfo</title>
    </head>
    <body>
        <header>
            <h1>franceinfo</h1>
            <nav>
                <div class="navbar">
                    <a href="index.php">home</a>
                    <a href="kategorija.php?id='politika'">politika</a>
                    <a href="kategorija.php?id='zabava'">zabava</a>
                    <a href="administracija.php">administracija</a>
                </div>
            </nav>
        </header>
        <?php
        include 'connect.php';
        define('UPLPATH', 'Slike/');
        ?>
        <main>
            <section class="clanci">
                <div class="clanci_sadrzaj">
                    <h2>POLITIKA</h2>
                    <div class="wrapper">
                    <?php
                        $query = "SELECT * FROM clanci WHERE arhiva=0 AND kategorija='politika' LIMIT 5";
                        $result = mysqli_query($baza, $query);
                        $i=0;
                        while($row = mysqli_fetch_array($result)) {
                        echo '<a href="clanak.php?id='.$row['id'].'">';
                        echo'<article>';
                        echo '<img src="' . UPLPATH . $row['slika'] . '" />';
                        echo '<p>';
                        echo $row['naslov'];
                        echo '</p>';
                        echo '</article>';
                        echo '</a>';
                    }?> 
                    </div>
                </div>
            </section>
            <section class="vijesti">
                <div class="vijesti_sadrzaj">
                    <h2>ZABAVA</h2>
                    <div class="wrapper">
                    <?php
                        $query = "SELECT * FROM clanci WHERE arhiva=0 AND kategorija='zabava' LIMIT 4";
                        $result = mysqli_query($baza, $query);
                        $i=0;
                        while($row = mysqli_fetch_array($result)) {
                        echo '<a href="clanak.php?id='.$row['id'].'">';
                        echo'<article>';
                        echo '<img src="' . UPLPATH . $row['slika'] . '" />';
                        echo '<p>';
                        echo $row['naslov'];
                        echo '</p>';
                        echo '</article>';
                        echo '</a>';
                    }?> 
                    </div>
                </div>
            </section>
        </main>
        <footer>
            <div class="footer_tekst"><p>france.tv</p></div>
        </footer>
    </body>
</html>
