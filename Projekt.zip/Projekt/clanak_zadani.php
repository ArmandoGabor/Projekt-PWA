<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" type="text/css" href="style.css" />
        <title>franceinfo</title>
    </head>
    <body>
        <header>
            <h1>franceinfo</h1>
            <nav>
            <div class="navbar">
                    <a href="index.php">home</a>
                    <a href="kategorija.php?id='politika'">politika</a>
                    <a href="kategorija.php?id='zabava'">zabava</a>
                    <a href="administracija.php">administracija</a>
                </div>
            </nav>
        </header>
        <main>
            <div class="wrapper_clanak">
                <section class="naslov">
                    <h1>
                        INFO FRANCEINFO. Européennes : les Républicains et le RNn'ont pas 
                        signé le plaidoyer de TransparencyInternational pour la lutte contre 
                        la corruption
                    </h1>
                    <p>
                        149 candidats français d'autres partis l'ont signé, dont
                        sept têtes de listes, selon l'ONG.
                    </p>
                </section>

                <section class="slika_clanak">
                    <img src="Slike/clanak_slika.png" alt="clanak_slika" />
                    <p>
                        Dans le cadre des élections européennes, l'ONG
                        Transparency International, qui lutte contre la
                        corruption, a invité tous les candidats à signer un
                        plaidoyer afin qu'ils s'engagent à protéger l'État de
                        droit, à lutter contre l'évasion fiscale et à améliorer
                        la transparence des institutions européennes.
                    </p>
                    <p>
                        Suite à un premier bilan effectué par l'ONG, pour le
                        moment, 149 candidats aux élections européennes en
                        France ont signé ce plaidoyer, révèle franceinfo
                        vendredi 17 mai. Parmi ces candidats qui s'engagent, on
                        retrouve sept têtes de liste aux européennes (La France
                        insoumise, Renaissance, Parti communiste, Europe
                        Ecologie-Les Verts, Debout la France, Envie d'Europe et
                        Parti Pirate). Aucun candidat des listes du
                        Rassemblement national et des Républicains n'a signé.
                        Or, ces deux listes regroupent à elles seules 40% des
                        candidats en position éligible.
                    </p>
                    <h2>"Encore des gens à convaincre"</h2>
                    <p>
                        Dans sa réponse à l'ONG, Jordan Bardella, tête de liste
                        RN, exprime des "désaccords de fond" avec les
                        propositions de l'ONG. La liste Les Républicains, elle
                        aussi non signataire du plaidoyer, parle néanmoins d'un
                        soutien de principe à la déontologie et à l'Etat de
                        droit. Ce sont des partis qui n'ont pas toujours été
                        engagés sur ces questions" affirme sur franceinfo
                        Marc-André Feffer, le président de l'ONG Transparency
                        International. "Et ce, soit pour des raisons liées à
                        l'Union européenne, soit liées au souhait de privilégier
                        finalement la déontologie individuelle."
                    </p>
                    <p>
                        Toutefois, "le verre est plus qu'à moitié plein" estime
                        Marc-André Feffer. Sur les 2 686 candidats aux
                        européennes, 149 ont signé le plaidoyer. "Ceux qui ont
                        répondu positivement nous aident beaucoup. Il y a encore
                        des gens à convaincre, nous souhaitons qu'il y ait un
                        effet de masse critique sur ces questionslà."
                    </p>
                    <p>
                        Courant mai, l'ONG Transparency International a réalisé
                        un sondage auprès de la population qui révèle que 88%
                        des Français jugent prioritaire le renforcement de
                        l'éthique et de la transparence dans les institutions
                        européennes.
                    </p>
                </section>
            </div>
        </main>
        <footer class="clanak_footer">
            <h1>franceinfo</h1>
        </footer>
    </body>
</html>
