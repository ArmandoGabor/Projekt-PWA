<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" type="text/css" href="style.css" />
        <title>franceinfo</title>
    </head>
    <body>
        <header>
            <h1>franceinfo</h1>
            <nav>
            <div class="navbar">
                    <a href="index.php">home</a>
                    <a href="kategorija.php?id='politika'">politika</a>
                    <a href="kategorija.php?id='zabava'">zabava</a>
                    <a href="administracija.php">administracija</a>
                </div>
            </nav>

        </header>
        <main>
            <div class="wrapper_clanak">
                <h1>Administracija</h1>
                <form
                    enctype="multipart/form-data"
                    name="login_forma"
                    action=""
                    method="post"
                >
                    <label for="korisnicko_ime">Korisničko ime:</label>
                    <input
                        type="text"
                        name="korisnicko_ime"
                        id="korisnicko_ime"
                    />
                    <span id="porukaUsername" class="bojaPoruke"></span>
                    <br />
                    <br />
                    <label for="lozinka">Lozinka:</label>
                    <input type="password" name="lozinka" id="lozinka" />
                    <span id="porukaPass" class="bojaPoruke"></span>
                    <br />
                    <button
                        type="submit"
                        value="Pošalji"
                        id="login"
                        name="login"
                    >
                        Prijava
                    </button>
                </form>
                <br/>

                <script type="text/javascript">
                    //Provjera valjanosti podataka unesenih u login formu
                    document.getElementById("login").onclick = function(event) {

                        var slanjeForme = true;

                        // Korisničko ime mora biti uneseno
                        var poljeUsername = document.getElementById("korisnicko_ime");
                        var username = document.getElementById("korisnicko_ime").value;
                        if (username.length == 0) {
                            slanjeForme = false;
                            poljeUsername.style.border="1px dashed red";
                            document.getElementById("porukaUsername").innerHTML="<br>Unesite korisničko ime!<br>";
                        } else {
                            poljeUsername.style.border="1px solid lawngreen";
                            document.getElementById("porukaUsername").innerHTML="";
                        }

                        // Provjera podudaranja lozinki
                        var poljePass = document.getElementById("lozinka");
                        var pass = document.getElementById("lozinka").value;
                        if (pass.length == 0) {
                            slanjeForme = false;
                            poljePass.style.border="1px dashed red";
                            document.getElementById("porukaPass").innerHTML="<br>Unesite lozinku!<br>";
                        } else {
                            poljePass.style.border="1px solid green";
                            poljePassRep.style.border="1px solid lawngreen";
                            document.getElementById("porukaPass").innerHTML="";
                        }

                        if (slanjeForme != true) {
                            event.preventDefault();
                        }
                    };
                </script>


                <?php
                    session_start();
                    include 'connect.php';
                    define('UPLPATH', 'Slike/');
                    $uspjesnaPrijava = false;
                    if (isset($_POST['login'])) {

                        $lozinka = $_POST["lozinka"];
                        $korisnicko_ime = $_POST["korisnicko_ime"];
                        $sql = "SELECT korisnicko_ime, lozinka, razina FROM korisnik WHERE korisnicko_ime = ?";
                        $stmt = mysqli_stmt_init($baza);
                        if (mysqli_stmt_prepare($stmt, $sql)) {
                            mysqli_stmt_bind_param($stmt, 's', $korisnicko_ime);
                            mysqli_stmt_execute($stmt);
                            mysqli_stmt_store_result($stmt);
                        }
                        mysqli_stmt_bind_result($stmt, $imeKorisnika, $lozinkaKorisnika, $levelKorisnika);
                        mysqli_stmt_fetch($stmt);

                        //Provjera lozinke
                        if (password_verify($_POST['lozinka'], $lozinkaKorisnika) && mysqli_stmt_num_rows($stmt) > 0) {
                            $uspjesnaPrijava = true;
                            // Provjera da li je admin
                            if($levelKorisnika == 1) {
                                $admin = true;
                                }
                                else {
                                $admin = false;
                                }
                            //postavljanje session varijabli
                            $_SESSION['$username'] = $imeKorisnika;
                            $_SESSION['$level'] = $levelKorisnika;
                        } 
                        else {
                            $uspjesnaPrijava = false;
                        }
                        
                    }

                    // Pokaži stranicu ukoliko je korisnik uspješno prijavljen i administrator je
                    if (($uspjesnaPrijava == true && $admin == true) || (isset($_SESSION['$username'])) && $_SESSION['$level'] == 1) {
                        //Ispis članaka
                        $query = "SELECT * FROM clanci";
                        $result = mysqli_query($baza, $query);
                        while($row = mysqli_fetch_array($result)) {
                            echo '<form enctype="multipart/form-data" action="skripta.php" method="post">
                                    <label for="naslov">Naslov vijesti:</label>
                                    <input type="text" name="naslov" autofocus  value="'.$row['naslov'].'"/>
                                    <label for="kratki_sazetak">Kratki sadržaj vijesti (do 50 znakova):</label>
                                    <textarea name="kratki_sazetak">'.$row['sazetak'].'></textarea>
                                    <label for="tekst_vijesti">Sadržaj vijesti:</label>
                                    <textarea name="tekst_vijesti">'.$row['tekst'].'</textarea>
                                    <label for="kategorija">Kategorija:</label>
                                    <select name="kategorija" value="' . $row['kategorija'] . '" autocomplete="off">
                                        <option value="politika"'; if($row['kategorija'] == 'politika'){echo("selected");}
                                        echo '>Politika</option>
                                        <option value="zabava"'; if($row['kategorija'] == 'zabava'){echo("selected");}
                                        echo '>Zabava</option>
                                    </select>
                                    <br />
                                    <br />
                                    <label for="slika">Slika:</label>
                                    <input type="file" id="picture"
                                        value="'. $row['slika'] . '" name="picture" autocomplete="off"/> <br><img src="' . UPLPATH .
                                            $row['slika'] . '" width=100px>
                                    <br />';

                                    if($row['arhiva'] == 0) {
                                        echo '<input type="checkbox" name="spremi_u_arhivu" id="spremi_u_arhivu"/>';
                                    }else {
                                        echo '<input type="checkbox" name="spremi_u_arhivu" id="spremi_u_arhivu" checked/>';
                                    }
                                    echo  '<label for="spremi_u_arhivu">Spremiti u arhivu</label>
                                        <br />
                                        <input type="hidden" name="id" class="form-field-textual" value="'.$row['id'].'">
                                        <input type="submit" value="Update" name="update" />
                                        <input type="submit" value="Delete" name="delete" />
                                        </form>';
                        }
                    }

                    // Pokaži poruku da je korisnik uspješno prijavljen, ali nije administrator
                    else if ($uspjesnaPrijava == true && $admin == false) {
                        echo '<p>Bok ' . $imeKorisnika . '! Uspješno ste prijavljeni, ali niste administrator.</p>';
                    } 
                    else if (isset($_SESSION['$username']) && $_SESSION['$level'] == 0) {
                        echo '<p>Bok ' . $_SESSION['$username'] . '! Uspješno ste prijavljeni, ali niste administrator.</p>';
                    }
                    //Pokaži poruku da prijava nije uspjela
                    else if ($uspjesnaPrijava == false && isset($_POST['login'])) {
                        echo "Morate se prvo registrirati!<br/>";
                        echo "<a href='registracija.php'><button name='posalji'>Registriraj se</button></a>";
                       
                    }
                    
                ?>
                    
            </div>
        </main>
        <footer class="clanak_footer razmak">
            <h1>franceinfo</h1>
        </footer>
    </body>
</html>
