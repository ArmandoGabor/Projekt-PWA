<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" type="text/css" href="style.css" />
        <title>franceinfo</title>
    </head>
    <body>
        <header>
            <h1>franceinfo</h1>
            <nav>
            <div class="navbar">
                    <a href="index.php">home</a>
                    <a href="kategorija.php?id='politika'">politika</a>
                    <a href="kategorija.php?id='zabava'">zabava</a>
                    <a href="administracija.php">administracija</a>
                </div>
            </nav>
        </header>
        <?php
            //Baza podataka
            include 'connect.php';
            define('UPLPATH', 'Slike/');
            $id=$_GET['id'];
            $query = "SELECT * FROM clanci WHERE id=$id ";
            $result = mysqli_query($baza, $query);
            while($row = mysqli_fetch_array($result)) {
                $slika = $row["slika"];
                $naslov = $row["naslov"];
                $kratki_sazetak = $row["sazetak"];
                $tekst_vijesti = $row["tekst"];
                $kategorija = $row["kategorija"];
                $datum = $row["datum"];
            }


        ?>
        <main>
            <div class="wrapper_clanak">
                <section class="naslov">
                    <h1>
                        <?php 
                            echo $naslov; 
                        ?>
                    </h1>
                    <p>
                        <?php 
                            echo $kratki_sazetak; 
                        ?>
                    </p>
                </section>

                <section class="slika_clanak">
                    <?php echo "<img src='Slike/$slika'>";?>
                        
                    <p>
                        <?php 
                            echo $tekst_vijesti; 
                        ?>
                    </p>
                </section>
            </div>
        </main>
        <footer class="clanak_footer">
            <h1>franceinfo</h1>
        </footer>
    </body>
</html>
