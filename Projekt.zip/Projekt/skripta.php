<?php
            include 'connect.php';
            $datum =date('d.m.Y.');
            $id=$_POST['id'];

            

            if (isset($_POST["naslov"])){
                $naslov = $_POST["naslov"];
            }
            if (isset($_POST["kratki_sazetak"])){
                $kratki_sazetak = $_POST["kratki_sazetak"];
            }
            if (isset($_POST["tekst_vijesti"])){
                $tekst_vijesti = $_POST["tekst_vijesti"];
            }
            if (isset($_POST["kategorija"])){
                $kategorija = $_POST["kategorija"];
            }
            if (isset($_POST["spremi_u_arhivu"])){
                $spremi_u_arhivu = 1;
            }else{
                $spremi_u_arhivu = 0;
            }
            
            $picture = $_FILES['picture']['name'];
            $target = "Slike/".$picture;

            //Upis novog članka u bazu
            if(isset($_POST['posalji'])){
                $query = "INSERT INTO clanci (datum, naslov, sazetak, tekst, slika, kategorija,
                        arhiva ) VALUES ('$datum', '$naslov', '$kratki_sazetak', '$tekst_vijesti', '$picture',
                        '$kategorija', '$spremi_u_arhivu')";

                $result = mysqli_query($baza, $query) or 
                    die ("Error querying database.");
                mysqli_close($baza);
            }
            
            //Brisanje članka iz baze
            if(isset($_POST['delete'])){
                $query = "DELETE FROM clanci WHERE id=$id ";
                $result = mysqli_query($baza, $query);
            }

            //Update članka iz baze
            if(isset($_POST['update'])){
                if ($picture != ""){
                    move_uploaded_file($_FILES['picture']['tmp_name'], $target);
                }else{
                    $query = "SELECT * FROM clanci WHERE id= $id";
                    $result = mysqli_query($baza, $query);
                    while($row = mysqli_fetch_array($result)) {
                        $picture = $row["slika"];
                    }
                }
                $query = "UPDATE clanci SET naslov='$naslov', sazetak='$kratki_sazetak', tekst='$tekst_vijesti',
                            slika='$picture', kategorija='$kategorija', arhiva='$spremi_u_arhivu' WHERE id=$id ";
                $result = mysqli_query($baza, $query);
                mysqli_close($baza);
            }

?>